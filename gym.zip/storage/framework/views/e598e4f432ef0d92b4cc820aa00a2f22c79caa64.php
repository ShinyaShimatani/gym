<?php $__env->startSection('content'); ?>

<div class="topics" style="padding: 16px">
<strong>新規会員登録フォーム</strong>
</div>

<?php if($errors->any()): ?>
<div style="color:red;">
<ul>
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li><?php echo e($error); ?></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>

<form method="post" action="<?php echo e(route('store')); ?>">

  <?php echo csrf_field(); ?>

  　<div class="form-group">
    <label for="age">名前</label>
    <input type="text" name="name" class="form-control">
    </div>

    <div class="form-group" style="padding-top: 8px">
    <label for="age">性別</label><br>
    <input id="gender-f" type="radio" name="gender" value="女性">
    <label for="gender-f">女性</label>
    <input id="gender-m" type="radio" name="gender" value="男性">
    <label for="gender-m">男性</label>

    <div class="form-group">
    <label for="age">年齢</label>
    <input type="text" name="age" class="form-control">
    </div>

    <div class="form-group">
    <label for="email">メールアドレス</label>
    <input type="text" name="email" class="form-control">
    </div>

    <div class="form-group">
    <label for="course">受講コース</label>
    <input type="text" name="course" class="form-control">
    </div>

    <div class="form-group">
    <label for="demand">当ジムへの要望</label>
    <input type="text" name="demand" class="form-control">
    </div>

    <div class="form-group" style="padding-top: 8px">
    <label for="demand_nec">要望検討</label><br>
    <input id="demand_nec-Y" type="radio" name="demand_nec" value="要検討">
    <label for="demand_nec-Y">要検討</label>
    <input id="demand_nec-N" type="radio" name="demand_nec" value="見送り">
    <label for="demand_nec-N">見送り</label><br>

    <button type="post" class="btn btn-primary" action="/confirm" style="margin: 16px">登録する</button>
  
</form>

  <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <p><?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

  <a href="<?php echo e(route('index')); ?>">キャンセル</a> 
 </form>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aggan\Desktop\phpstudy\gym\resources\views/register.blade.php ENDPATH**/ ?>