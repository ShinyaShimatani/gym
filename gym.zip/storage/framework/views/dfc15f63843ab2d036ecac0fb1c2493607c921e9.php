<?php $__env->startSection('content'); ?>

 <a href="<?php echo e(route('create')); ?>">メモを作成</a>

 <?php $__currentLoopData = $memos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div>
  <span><?php echo e($memo->content); ?></span>
  <a href="<?php echo e(route('edit',['id'=>$memo->id])); ?>">編集</a>
  <a href="<?php echo e(route('delete',['id'=>$memo->id])); ?>">削除</a>
 </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aggan\Desktop\phpstudy\memo\resources\views/index.blade.php ENDPATH**/ ?>