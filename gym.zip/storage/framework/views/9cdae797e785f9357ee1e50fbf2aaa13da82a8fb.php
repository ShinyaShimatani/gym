<?php $__env->startSection('content'); ?>

<h>新規会員登録画面</h>

<form method="post" action="/members/register"></form>

<?php echo csrf_field(); ?>

<form>
  <div class="form-group">
    <label for="name">名前</label>
    <input type="text" name="name" class="form-control">
    </div>

    <div class="form-group">
    <label for="gender">性別</label>
    <input type="text" name="gender" class="form-control">
    </div>

    <div class="form-group">
    <label for="age">年齢</label>
    <input type="text" name="age" class="form-control">
    </div>

    <div class="form-group">
    <label for="email">メールアドレス</label>
    <input type="text" name="email" class="form-control">
    </div>

    <div class="form-group">
    <label for="course">受講コース</label>
    <input type="text" name="course" class="form-control">
    </div>

    <div class="form-group">
    <label for="profile">意気込み / 当ジムへの一言</label>
    <input type="text" name="profile" class="form-control">
    </div>

  <button type="post" class="btn btn-primary" action="/members/register">登録する</button>
  
</form>

  <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <p><?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

  <a href="<?php echo e(route('index')); ?>">キャンセル</a> 
 </form>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aggan\Desktop\phpstudy\gym\resources\views/create.blade.php ENDPATH**/ ?>