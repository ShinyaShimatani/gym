<?php $__env->startSection('content'); ?>

 <form method="POST" action="<?php echo e(route('update',['id'=>$memo->id])); ?>">
 <?php echo csrf_field(); ?>
  <textarea name="content" rows="4"><?php echo e($memo->content); ?></textarea>
  <button type="submit">編集</button>
  <a href="<?php echo e(route('index')); ?>">キャンセル</a> 
 </form>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aggan\Desktop\phpstudy\memo\resources\views/edit.blade.php ENDPATH**/ ?>