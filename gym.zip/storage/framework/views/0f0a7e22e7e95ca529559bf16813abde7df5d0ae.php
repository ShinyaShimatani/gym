<?php $__env->startSection('content'); ?>
 
 <h1>利用者一覧</h1>

    <div class="row">
        <div class="col-sm-12">
            <a href="<?php echo e(route('register')); ?>" class="btn btn-primary" style="margin:20px;">利用者を登録する</a>
        </div>
    </div>

    <!-- table -->
    <table class="table table-striped">

    　　<th>id</th>
        <th>名前</th>
        <th>性別</th>
        <th>年齢</th>
        <th>メールアドレス</th>
        <th>受講コース</th>
        <th>当ジムへの要望</th>
        <th>要望検討</th>

        <th>処理</th>
    <!-- loop -->
    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($member->id); ?></td>
            <td><?php echo e($member->name); ?></td>
            <td><?php echo e($member->gender); ?></td>
            <td><?php echo e($member->age); ?></td>
            <td><?php echo e($member->email); ?></td>
            <td><?php echo e($member->course); ?></td>
            <td><?php echo e($member->demand); ?></td>
            <td><?php echo e($member->demand_nec); ?></td>

            <td><a href="<?php echo e(route('edit',['id'=>$member->id])); ?>">編集</a> ; 
            <a href="<?php echo e(route('delete',['id'=>$member->id])); ?>">削除</a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aggan\Desktop\phpstudy\gym\resources\views/index.blade.php ENDPATH**/ ?>