<?php $__env->startSection('content'); ?>

<h3>完了</h3>
<p>登録しました!</p>

<a href="<?php echo e(route('form.show')); ?>">戻る</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aggan\Desktop\phpstudy\gym\resources\views/form_complete.blade.php ENDPATH**/ ?>