<?php $__env->startSection('content'); ?>

 <form method="POST" action="<?php echo e(route('store')); ?>">
 <?php echo csrf_field(); ?>
  <textarea name="content" rows="4"></textarea>

  <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <p><?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

  <button type="submit">作成</button>
  <a href="<?php echo e(route('index')); ?>">キャンセル</a> 
 </form>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aggan\Desktop\phpstudy\memo\resources\views/create.blade.php ENDPATH**/ ?>