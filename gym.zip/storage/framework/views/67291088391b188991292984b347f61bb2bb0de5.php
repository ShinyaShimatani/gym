<?php $__env->startSection('content'); ?>

<h>確認</h>
 <form method="post" action="<?php echo e(route('form.complete')); ?>">
        <?php echo csrf_field(); ?>

        <label>名前</label>
        <div>
                <?php echo e($member); ?>

        </div>

        <label>性別</label>
        <div>
                <?php echo e($gender); ?>

        </div>

        <label>年齢</label>
        <div>
                <?php echo e($age); ?>

        </div>

        <label>メールアドレス</label>
        <div>
                <?php echo e($email); ?>

        </div>

        <label>受講コース</label>
        <div>
                <?php echo e($course); ?>

        </div>

        <label>意気込み / 当ジムへの一言</label>
        <div>
                <?php echo e($profile); ?>

        </div>

        <input name="back" type="submit" value="戻る" />
        <input type="submit" value="登録する" />

 </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aggan\Desktop\phpstudy\gym\resources\views/form_confirm.blade.php ENDPATH**/ ?>