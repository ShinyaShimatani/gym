@extends('layout')

@section('content')

<h3>完了</h3>
<p>登録しました!</p>

<a href="{{ route('form.show') }}">戻る</a>

@endsection